<html>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-10646"/>
        <meta charset="UTF-8">
        <LINK REL="SHORTCUT ICON" href="../Media/Image/icone.jpg" /> <!-- Icone de l'onglet de la page web -->

        <link rel="stylesheet" href="../Css/documents.css" /> <!-- Importations du css -->
            
            <head>
                <title>Documents</title> <!-- Titre de l'onglet de la page web -->
            </head>
    <body>
        <nav class="Nav-Accueil-Liens">
            <nav class="Nav-Box">
<!-- BOX DU TITRE -->
                <nav class="Titre-Nav">
                    <h1>Dossier</h1>
                </nav>

                    <nav class="Nav-Dossier">
                        <?php
                            $liens = 0;
                            for($o = 0; $o < sizeof($dossier); $o++)  
                                        {
                                            if($tabliens[$liens] != "0")
                                            {
                                                ?>
                                                    <div class="div-documents">
                                                        <?php
                                                            echo "<a href='../Documents/".$dossier[$liens]."' class='a-doc'>".$o." :".$dossier[$liens]."</a>";
                                                            echo "<br>";
                                                        ?>
                                                    </div>
                                                <?php
                                            }
                                            $liens++;    
                                        }
                        ?>
                    </nav>
            </nav>
            <div class="headers-flo">
                <a href="../" class="a-flo">ACCUEIL</a>
            </div>
            <nav class="Nav-Box">
<!-- BOX DU TITRE -->
                <nav class="Titre-Nav">
                    <h1>Fichiers</h1>
                </nav>

                    <nav class="Nav-Fichiers">
                        <?php
                                $liens = 0;
                                    for($o = 0; $o < sizeof($fichiers); $o++) 
                                    {
                                        if($tabliens[$liens] != "0")
                                            {
                                                ?>
                                                    <div class="div-documents">
                                                        <?php
                                                        echo "<a href='../Documents/".$fichiers[$liens]."' class='a-doc'>".$o." :".$fichiers[$liens]."</a>";
                                                            echo "<br>";
                                                        ?>
                                                    </div>
                                                <?php
                                            }
                                            $liens++;    
                                    }
                                    
                                    closedir($dir);
                                
                        ?>
                    </nav>
            </nav>
        </nav>
    </body>
</html>
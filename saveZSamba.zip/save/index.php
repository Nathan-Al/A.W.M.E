<html>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-10646"/>
        <meta charset="UTF-8">
        <LINK REL="SHORTCUT ICON" href="../Media/Image/icone.jpg" /> <!-- Icone de l'onglet de la page web -->

        <link rel="stylesheet" href="Css/Menu.css" /> <!-- Importations du css -->
        
        <head>
            <title>Accueil</title> <!-- Titre de l'onglet de la page web -->
        </head>

            <body class="Menu-Body">
                <header><h1> Bienvenue sur la page de gestion de samba </h1></header>
                
                <div id="conteneur">
                    <div class="Menu-comp">
                        <nav class="Nav-Liens">
                            <a href="Controller/affichage-image.php?chgp=0 & page=1 " class="Liens-Accueil">Image</a>
                            <img src="media-site/img.jpg" class="Nav-Image"/>
                        </nav>
                        <nav class="Nav-Liens">
                            <a href="Controller/controll-documents.php" class="Liens-Accueil">Documents</a>
                            <img src="media-site/doc.jpg" class="Nav-Image"/>
                        </nav>
                        <nav class="Nav-Liens">
                            <a href="Controller/controll-video.php?video=default" class="Liens-Accueil">Video</a>
                            <img src="media-site/vid.jpg" class="Nav-Image"/>
                        </nav>
                        <nav class="Nav-Liens">
                            <a href="" class="Liens-Accueil">Disque Durs</a>
                            <img src="media-site/ddd.jpg" class="Nav-Image"/>
                        </nav>
                    </div>
                </div>
            </body>
</html>